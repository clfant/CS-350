/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <ti/drivers/UART2.h>
#include <ti/drivers/GPIO.h>
#include <ti/drivers/Timer.h>
#include <ti/drivers/I2C.h>
#include <string.h> // For strlen

/* Driver configuration */
#include "ti_drivers_config.h"

// UART Global Variables
char output[64];
int bytesToSend;

// Driver Handle - Global variable
UART2_Handle uart;

// Temperature Control Variables
int16_t currentTemperature = 0; // Current temperature from the sensor
int16_t setPointTemperature = 20; // Initial set-point temperature
unsigned long secondsCount = 0; // Elapsed seconds since reset

// Timer Handles - Global variables
Timer_Handle buttonTimer;
Timer_Handle tempTimer;
Timer_Handle reportTimer;
volatile unsigned char buttonFlag = 0;
volatile unsigned char tempFlag = 0;
volatile unsigned char reportFlag = 0;

void buttonCallback(Timer_Handle myHandle, int_fast16_t status) {
    buttonFlag = 1; // Set the button check flag
}

void tempCallback(Timer_Handle myHandle, int_fast16_t status) {
    tempFlag = 1; // Set the temperature check flag
}

void reportCallback(Timer_Handle myHandle, int_fast16_t status) {
    reportFlag = 1; // Set the report flag
}

void initTimers(void) {
    Timer_Params params;

    // Init the driver
    Timer_init();

    // Configure button timer (200 ms)
    Timer_Params_init(&params);
    params.period = 200000; // 200 ms
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = buttonCallback;
    buttonTimer = Timer_open(CONFIG_TIMER_0, &params);
    if (buttonTimer == NULL) {
        // Handle error
    }
    Timer_start(buttonTimer);

    // Configure temperature check timer (500 ms)
    Timer_Params_init(&params);
    params.period = 500000; // 500 ms
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = tempCallback;
    tempTimer = Timer_open(CONFIG_TIMER_1, &params);
    if (tempTimer == NULL) {
        // Handle error
    }
    Timer_start(tempTimer);

    // Configure report timer (1000 ms)
    Timer_Params_init(&params);
    params.period = 1000000; // 1 second
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = reportCallback;
    reportTimer = Timer_open(CONFIG_TIMER_2, &params);
    if (reportTimer == NULL) {
        // Handle error
    }
    Timer_start(reportTimer);
}

void initUART2(void) {
    UART2_Params uartParams;

    // Init the driver
    UART2_init();

    // Configure the driver for UART2
    UART2_Params_init(&uartParams);
    uartParams.baudRate = 115200;  // Set baud rate
    uartParams.dataLength = UART2_DATA_LENGTH_8; // Set data length (default to 8 bits)
    uartParams.parityType = UART2_PARITY_NONE;   // No parity
    uartParams.stopBits = UART2_STOP_ONE;        // One stop bit

    // Open UART2
    uart = UART2_open(CONFIG_UART2_0, &uartParams);
    if (uart == NULL) {
        while (1); // UART_open() failed
    }
}

void initI2C(void) {
    // Initialization code for I2C...
}

int16_t readTemp(void) {
    // Read temperature code...
    // Make sure to return the current temperature read from the sensor
}

void displayReport(void) {
    snprintf(output, sizeof(output), "<%02d,%02d,%d,%04lu>\n",
             currentTemperature, setPointTemperature,
             (currentTemperature < setPointTemperature) ? 1 : 0,
             secondsCount);
    UART2_write(uart, output, strlen(output));
}

void *mainThread(void *arg0) {
    GPIO_init();
    initUART2(); // Ensure UART2 is initialized first
    initI2C();  // Initialize I2C
    initTimers(); // Initialize the timers

    // Configure GPIO for the LED
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    while (1) {
        // Check buttons every 200 ms
        if (buttonFlag) {
            buttonFlag = 0; // Reset the flag

            // Check button states and adjust set-point
            if (GPIO_read(CONFIG_GPIO_BUTTON_0) == 0) { // Button 0 pressed
                setPointTemperature++;
            }
            if (GPIO_read(CONFIG_GPIO_BUTTON_1) == 0) { // Button 1 pressed
                setPointTemperature--;
            }
        }

        // Check temperature every 500 ms
        if (tempFlag) {
            tempFlag = 0; // Reset the flag

            // Read temperature
            currentTemperature = readTemp();

            // Control LED based on set-point
            if (currentTemperature < setPointTemperature) {
                GPIO_write(CONFIG_GPIO_LED_0, 1); // Turn on heater
            } else {
                GPIO_write(CONFIG_GPIO_LED_0, 0); // Turn off heater
            }
        }

        // Report every second
        if (reportFlag) {
            reportFlag = 0; // Reset the flag
            secondsCount++;
            displayReport(); // Send report to server
        }
    }

    return (NULL);
}
